import java.util.List;

public class Answer {
    List<String> documents;
    List<String> documentId;
    List<List<String>> answer;
    String id;
    List<Snippet> snippets;
}
