public class Document {
    String id;
    String text;
}
