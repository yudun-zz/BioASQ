import java.util.List;

public class Questions {
    List<Question> questions;
}
