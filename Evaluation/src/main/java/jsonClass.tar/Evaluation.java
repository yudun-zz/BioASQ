import com.google.gson.*;

import java.util.HashSet;
import java.util.List;

public class Evaluation {
    private int correct = 0;
    private int total = 0;
    private void run(String jsonString)
    {
        Gson gson = new GsonBuilder().create();
        Question[] value = gson.fromJson(jsonString, Question[].class);
        System.out.print(value[0].goldStandard.snippets.get(0).document);

    }

    public double getPrecision()
    {
        return ((double) correct) / total;
    }

    public static void main(String[] args)
    {
        Evaluation evaluation = new Evaluation();
        evaluation.run("[{\"body\": \"Which genes have been found mutated in Gray platelet syndrome patients?\", \"type\": \"list\", \"id\": \"52f89f4f2059c6d71c00004e\", \"goldStandard\": {\"documents\": [\"24325358\", \"23100277\", \"21765412\", \"17209061\"], \"answer\": [[\"NBEAL2\"], [\"GFI1B\"], [\"GATA1\"]], \"id\": \"52f89f4f2059c6d71c00004e\", \"snippets\": [{\"text\": \"We detected a nonsense mutation in the gene encoding the transcription factor GFI1B (growth factor independent 1B) that causes autosomal dominant gray platelet syndrome. \", \"begin\": 145, \"document\": \"24325358\", \"end\": 315, \"section\": \"abstract\"}]}}]");
    }
}
