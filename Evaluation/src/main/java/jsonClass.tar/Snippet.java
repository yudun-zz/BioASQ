public class Snippet {
    String text;
    int begin;
    String document;
    int end;
    String section;
}
