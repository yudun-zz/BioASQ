import java.util.List;

public class Question {
    public String body;
    Answer retrieved;
    String type;
    String id;
    Answer goldStandard;
}
